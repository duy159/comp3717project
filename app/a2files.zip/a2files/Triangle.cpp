#include "Triangle.h"
using namespace std;

Triangle::Triangle(istream& is) {
  is >> v1_ >> v2_ >> v3_; 
  if (!is)
    throw "Triangle::Triangle(const std::string&)";
}

void 
Triangle::draw() const {
  cerr << "[T: " << v1_ << ", " << v2_ << ", " << v3_ << "]" << endl; 
}
