// an sample program showing how to use a ShapeFactory
#include <iostream>
#include <vector>
#include <memory>
#include "ShapeFactory.h"
#include "Shape.h"
using namespace std;

int main() {
  vector<std::shared_ptr<Shape>>  v;
  shared_ptr<Shape>               s;
  ShapeFactory                    sf(cin);

  while ((s = sf.create()))
    v.push_back(s);
   
  for (vector<std::shared_ptr<Shape>>::size_type i = 0, sz = v.size(); 
       i < sz; i++)
    v[i]->draw();
}
