#include "Circle.h"
using namespace std;

Circle::Circle(istream& is) {
  is >> centre_ >> radius_; 
  if (!is)
    throw "Circle::Circle(const std::string&)";
}  

void 
Circle::draw() const {
  cerr << "[C: " << centre_ << ", " << radius_ << "]" << endl; 
} 

